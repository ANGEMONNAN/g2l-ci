const { escapeHtml } = require("../lib/helpers");

// Shared line-items editor used by both devis and factures forms.
function lineItemsEditor({ catalogue, existingLignes, formIdPrefix }) {
  const options = catalogue
    .map((a) => `<option value="${a.id}" data-price="${a.prixUnitaire}" data-label="${escapeHtml(a.designation)}">${escapeHtml(a.reference)} — ${escapeHtml(a.designation)}</option>`)
    .join("");

  const rowHtml = (ligne) => `
    <tr class="line-row">
      <td>
        <select name="articleId" class="art-select" required>
          <option value="">— choisir —</option>
          ${catalogue
            .map(
              (a) =>
                `<option value="${a.id}" data-price="${a.prixUnitaire}" ${ligne && String(ligne.articleId) === String(a.id) ? "selected" : ""}>${escapeHtml(a.reference)} — ${escapeHtml(a.designation)}</option>`
            )
            .join("")}
        </select>
      </td>
      <td style="width:90px"><input type="number" name="quantite" class="qty-input" min="1" step="1" value="${ligne ? ligne.quantite : 1}" required></td>
      <td style="width:130px" class="line-price num">—</td>
      <td style="width:130px" class="line-total num">—</td>
      <td style="width:36px"><button type="button" class="remove-line" onclick="this.closest('tr').remove(); recalc${formIdPrefix}();">✕</button></td>
    </tr>`;

  const initialRows = existingLignes && existingLignes.length ? existingLignes.map(rowHtml).join("") : rowHtml(null);

  return `
    <table class="lines" id="lines-${formIdPrefix}">
      <thead><tr><th>Article</th><th>Qté</th><th class="num">PU HT</th><th class="num">Montant HT</th><th></th></tr></thead>
      <tbody>${initialRows}</tbody>
    </table>
    <button type="button" class="btn secondary small" onclick="addLine${formIdPrefix}()">+ Ajouter une ligne</button>

    <div class="totals-box" style="margin-top:18px;">
      <div class="line"><span>Sous-total HT</span><span id="sub-${formIdPrefix}">0 F CFA</span></div>
      <div class="line"><span>TVA</span><span id="tva-${formIdPrefix}">0 F CFA</span></div>
      <div class="line total"><span>Total TTC</span><span id="ttc-${formIdPrefix}">0 F CFA</span></div>
    </div>

    <script>
      function fmt${formIdPrefix}(n) { return Math.round(n).toLocaleString('fr-FR') + ' F CFA'; }
      function recalc${formIdPrefix}() {
        var rows = document.querySelectorAll('#lines-${formIdPrefix} .line-row');
        var sub = 0;
        rows.forEach(function(row) {
          var sel = row.querySelector('.art-select');
          var qty = Number(row.querySelector('.qty-input').value) || 0;
          var opt = sel.options[sel.selectedIndex];
          var price = opt ? Number(opt.getAttribute('data-price')) || 0 : 0;
          var lineTotal = price * qty;
          row.querySelector('.line-price').textContent = price ? fmt${formIdPrefix}(price) : '—';
          row.querySelector('.line-total').textContent = price ? fmt${formIdPrefix}(lineTotal) : '—';
          sub += lineTotal;
        });
        var taux = Number(document.getElementById('tauxTva-${formIdPrefix}').value) || 0;
        var tva = sub * (taux / 100);
        document.getElementById('sub-${formIdPrefix}').textContent = fmt${formIdPrefix}(sub);
        document.getElementById('tva-${formIdPrefix}').textContent = fmt${formIdPrefix}(tva);
        document.getElementById('ttc-${formIdPrefix}').textContent = fmt${formIdPrefix}(sub + tva);
      }
      function addLine${formIdPrefix}() {
        var tbody = document.querySelector('#lines-${formIdPrefix} tbody');
        var tr = document.createElement('tr');
        tr.className = 'line-row';
        tr.innerHTML = '<td><select name="articleId" class="art-select" required><option value="">— choisir —</option>${catalogue
          .map((a) => `<option value=\\'${a.id}\\' data-price=\\'${a.prixUnitaire}\\'>${escapeHtml(a.reference)} — ${escapeHtml(a.designation)}</option>`)
          .join("")}</select></td><td style="width:90px"><input type="number" name="quantite" class="qty-input" min="1" step="1" value="1" required></td><td style="width:130px" class="line-price num">—</td><td style="width:130px" class="line-total num">—</td><td style="width:36px"><button type="button" class="remove-line" onclick="this.closest(\\'tr\\').remove(); recalc${formIdPrefix}();">✕</button></td>';
        tbody.appendChild(tr);
        tr.querySelector('.art-select').addEventListener('change', recalc${formIdPrefix});
        tr.querySelector('.qty-input').addEventListener('input', recalc${formIdPrefix});
      }
      document.querySelectorAll('#lines-${formIdPrefix} .art-select').forEach(function(el){ el.addEventListener('change', recalc${formIdPrefix}); });
      document.querySelectorAll('#lines-${formIdPrefix} .qty-input').forEach(function(el){ el.addEventListener('input', recalc${formIdPrefix}); });
      document.getElementById('tauxTva-${formIdPrefix}').addEventListener('input', recalc${formIdPrefix});
      recalc${formIdPrefix}();
    </script>
  `;
}

module.exports = { lineItemsEditor };
