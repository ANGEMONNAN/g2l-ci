const { escapeHtml } = require("../lib/helpers");
const { roleLabel } = require("../lib/roles");

const NAV = [
  { href: "/", label: "Tableau de bord", key: "dashboard" },
  { href: "/devis", label: "Devis", key: "devis" },
  { href: "/factures", label: "Factures", key: "factures" },
  { href: "/catalogue", label: "Catalogue", key: "catalogue" },
  { href: "/clients", label: "Clients", key: "clients" },
  { href: "/stock", label: "Stock", key: "stock" },
  { href: "/achats", label: "Demandes d'achat", key: "achats" },
];

function layout({ user, title, active, body, flash }) {
  const navHtml = NAV.map(
    (n) => `<a class="nav-link${active === n.key ? " active" : ""}" href="${n.href}">${n.label}</a>`
  ).join("\n");

  return `<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${escapeHtml(title)} — G2L</title>
<link rel="icon" href="/public/img/icone.svg">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Schibsted+Grotesk:wght@300;400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/public/style.css">
</head>
<body>
<div class="shell" id="shell">
  <aside class="sidebar">
    <div class="brand">
      <img src="/public/img/icone-sur-navy.svg" alt="G2L" width="28">
      <div>
        <div class="brand-name">G2L</div>
        <div class="brand-sub">Système de gestion</div>
      </div>
      <button class="menu-toggle" onclick="document.getElementById('shell').classList.toggle('nav-open')" aria-label="Menu">☰</button>
    </div>
    <nav class="nav">${navHtml}</nav>
    <div class="sidebar-footer">
      ${
        user
          ? `<div class="user-chip">
              <div class="user-name">${escapeHtml(user.nom)}</div>
              <div class="user-role">${escapeHtml(roleLabel(user.role))}</div>
            </div>
            <a class="logout-link" href="/logout">Se déconnecter</a>`
          : ""
      }
    </div>
  </aside>
  <main class="content">
    ${flash ? `<div class="flash ${flash.type || "info"}">${escapeHtml(flash.message)}</div>` : ""}
    ${body}
  </main>
</div>
</body>
</html>`;
}

function authLayout({ title, body, flash }) {
  return `<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${escapeHtml(title)} — G2L</title>
<link rel="icon" href="/public/img/icone.svg">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Schibsted+Grotesk:wght@300;400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/public/style.css">
</head>
<body class="auth-body">
  <div class="auth-card">
    <img src="/public/img/icone.svg" alt="G2L" width="44">
    <h1>G2L</h1>
    <p class="auth-sub">Système de gestion interne</p>
    ${flash ? `<div class="flash ${flash.type || "info"}">${escapeHtml(flash.message)}</div>` : ""}
    ${body}
  </div>
</body>
</html>`;
}

module.exports = { layout, authLayout };
