const { fmtCurrency } = require("../lib/helpers");

function dashboardBody({ kpis, alertes, demandesEnAttente }) {
  return `
    <div class="page-head">
      <div>
        <p class="eyebrow">G2L — Pilotage</p>
        <h1>Tableau de bord</h1>
        <p>Vue d'ensemble de l'activité — mise à jour en temps réel.</p>
      </div>
    </div>

    <div class="kpi-row">
      <div class="kpi-card"><div class="label">Devis enregistrés</div><div class="value">${kpis.nbDevis}</div></div>
      <div class="kpi-card"><div class="label">Factures émises</div><div class="value">${kpis.nbFactures}</div></div>
      <div class="kpi-card"><div class="label">CA facturé (TTC)</div><div class="value small">${fmtCurrency(kpis.caFacture)}</div></div>
      <div class="kpi-card"><div class="label">CA encaissé</div><div class="value small">${fmtCurrency(kpis.caEncaisse)}</div></div>
    </div>
    <div class="kpi-row">
      <div class="kpi-card"><div class="label">Valeur du stock (produits)</div><div class="value small">${fmtCurrency(kpis.valeurStock)}</div></div>
      <div class="kpi-card"><div class="label">Articles à réapprovisionner</div><div class="value">${kpis.articlesAlerte}</div></div>
      <div class="kpi-card"><div class="label">Demandes d'achat en attente</div><div class="value">${kpis.demandesAttente}</div></div>
      <div class="kpi-card"><div class="label">Prochains N°</div><div class="value small">${kpis.prochainDevis}<br>${kpis.prochainFacture}</div></div>
    </div>

    <div class="card">
      <h2>Articles à réapprovisionner</h2>
      ${
        alertes.length
          ? `<table class="data"><thead><tr><th>Référence</th><th>Désignation</th><th class="num">Stock</th><th class="num">Seuil</th></tr></thead><tbody>
              ${alertes.map((a) => `<tr><td>${a.reference}</td><td>${a.designation}</td><td class="num">${a.stock}</td><td class="num">${a.seuilAlerte}</td></tr>`).join("")}
            </tbody></table>`
          : `<p class="section-note">Aucune alerte de stock pour le moment.</p>`
      }
    </div>

    <div class="card">
      <h2>Demandes d'achat en attente de validation</h2>
      ${
        demandesEnAttente.length
          ? `<table class="data"><thead><tr><th>N°</th><th>Direction</th><th>Article</th><th class="num">Qté</th><th>Urgence</th></tr></thead><tbody>
              ${demandesEnAttente
                .map(
                  (d) =>
                    `<tr><td>${d.numero}</td><td>${d.directionLabel}</td><td>${d.article}</td><td class="num">${d.quantite}</td><td>${d.urgence}</td></tr>`
                )
                .join("")}
            </tbody></table><p class="section-note"><a href="/achats">Voir toutes les demandes →</a></p>`
          : `<p class="section-note">Aucune demande en attente.</p>`
      }
    </div>
  `;
}

module.exports = { dashboardBody };
