const { escapeHtml, fmtDate } = require("../lib/helpers");

const STATUT_LABEL = { en_attente: "En attente", approuvee: "Approuvée", rejetee: "Rejetée" };
const STATUT_CLASS = { en_attente: "attente", approuvee: "approuvee", rejetee: "rejetee" };

function achatsListBody({ items, isGerant }) {
  const rows = items
    .map(
      (d) => `<tr>
        <td>${escapeHtml(d.numero)}</td>
        <td>${fmtDate(d.date)}</td>
        <td>${escapeHtml(d.directionLabel)}</td>
        <td>${escapeHtml(d.demandeurNom)}</td>
        <td>${escapeHtml(d.article)}</td>
        <td class="num">${d.quantite}</td>
        <td><span class="badge ${d.urgence === "Urgente" ? "danger" : "muted"}">${d.urgence}</span></td>
        <td><span class="badge ${STATUT_CLASS[d.statut]}">${STATUT_LABEL[d.statut]}</span></td>
        <td>
          ${
            isGerant && d.statut === "en_attente"
              ? `<form method="POST" action="/achats/${d.id}/valider" style="display:inline"><button class="btn small gold" type="submit">Valider</button></form>
                 <form method="POST" action="/achats/${d.id}/rejeter" style="display:inline"><button class="btn small danger" type="submit">Rejeter</button></form>`
              : ""
          }
        </td>
      </tr>`
    )
    .join("");
  return `
    <div class="page-head">
      <div><p class="eyebrow">G2L — Achats</p><h1>Demandes d'achat</h1><p>Circulent entre toutes les directions ; validation par la Direction Générale.</p></div>
      <a class="btn gold" href="/achats/new">+ Nouvelle demande</a>
    </div>
    <div class="card">
      <table class="data">
        <thead><tr><th>N°</th><th>Date</th><th>Direction</th><th>Demandeur</th><th>Article</th><th class="num">Qté</th><th>Urgence</th><th>Statut</th><th></th></tr></thead>
        <tbody>${rows || `<tr class="empty-row"><td colspan="9">Aucune demande d'achat pour l'instant.</td></tr>`}</tbody>
      </table>
    </div>
  `;
}

function achatFormBody({ numero, today }) {
  return `
    <div class="page-head"><div><p class="eyebrow">G2L — Achats</p><h1>Nouvelle demande d'achat</h1><p>Numéro suggéré : ${numero}</p></div></div>
    <div class="card">
      <form class="stack" method="POST" action="/achats/new">
        <div class="row-2">
          <div class="field"><label>Numéro</label><input name="numero" required value="${numero}"></div>
          <div class="field"><label>Date</label><input type="date" name="date" required value="${today}"></div>
        </div>
        <div class="field"><label>Article / matériel demandé</label><input name="article" required placeholder="Ex. : 2 imprimantes laser"></div>
        <div class="row-2">
          <div class="field"><label>Quantité</label><input type="number" name="quantite" min="1" step="1" required value="1"></div>
          <div class="field"><label>Urgence</label>
            <select name="urgence">
              <option value="Normale">Normale</option>
              <option value="Urgente">Urgente</option>
            </select>
          </div>
        </div>
        <div class="field"><label>Justification</label><textarea name="justification" placeholder="Pourquoi cet achat est nécessaire"></textarea></div>
        <div class="actions">
          <button class="btn gold" type="submit">Envoyer la demande</button>
          <a class="btn secondary" href="/achats">Annuler</a>
        </div>
      </form>
    </div>
  `;
}

module.exports = { achatsListBody, achatFormBody, STATUT_LABEL, STATUT_CLASS };
