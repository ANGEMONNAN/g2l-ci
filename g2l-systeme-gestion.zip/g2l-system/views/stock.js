const { escapeHtml, fmtDate } = require("../lib/helpers");
const { computeStock, statutStock } = require("../lib/business");

function stockOverviewBody({ produits, mouvements }) {
  const stockRows = produits
    .map((a) => {
      const stock = computeStock(a.id);
      const statut = statutStock(a);
      return `<tr>
        <td>${escapeHtml(a.reference)}</td>
        <td>${escapeHtml(a.designation)}</td>
        <td class="num">${stock}</td>
        <td class="num">${a.seuilAlerte === "" ? "—" : a.seuilAlerte}</td>
        <td><span class="badge ${statut === "OK" ? "ok" : "danger"}">${statut}</span></td>
      </tr>`;
    })
    .join("");

  const mvtRows = mouvements
    .slice()
    .reverse()
    .map(
      (m) => `<tr>
        <td>${fmtDate(m.date)}</td>
        <td>${escapeHtml(m.articleRef)}</td>
        <td><span class="badge ${m.type === "Entrée" ? "ok" : "muted"}">${m.type}</span></td>
        <td class="num">${m.quantite}</td>
        <td>${escapeHtml(m.refDocument || "")}</td>
        <td>${escapeHtml(m.commentaire || "")}</td>
      </tr>`
    )
    .join("");

  return `
    <div class="page-head">
      <div><p class="eyebrow">G2L — Stock</p><h1>Stock &amp; mouvements</h1><p>Le stock se calcule automatiquement à partir des mouvements enregistrés.</p></div>
      <a class="btn gold" href="/stock/new">+ Nouveau mouvement</a>
    </div>

    <div class="card">
      <h2>Stock actuel (produits)</h2>
      <table class="data">
        <thead><tr><th>Référence</th><th>Désignation</th><th class="num">Stock</th><th class="num">Seuil</th><th>Statut</th></tr></thead>
        <tbody>${stockRows || `<tr class="empty-row"><td colspan="5">Aucun produit avec suivi de stock — ajoute un article de type « Produit » dans le catalogue.</td></tr>`}</tbody>
      </table>
    </div>

    <div class="card">
      <h2>Historique des mouvements</h2>
      <table class="data">
        <thead><tr><th>Date</th><th>Article</th><th>Type</th><th class="num">Quantité</th><th>Réf. document</th><th>Commentaire</th></tr></thead>
        <tbody>${mvtRows || `<tr class="empty-row"><td colspan="6">Aucun mouvement enregistré.</td></tr>`}</tbody>
      </table>
    </div>
  `;
}

function stockFormBody({ produits, today }) {
  return `
    <div class="page-head"><div><p class="eyebrow">G2L — Stock</p><h1>Nouveau mouvement</h1></div></div>
    <div class="card">
      <form class="stack" method="POST" action="/stock/new">
        <div class="row-2">
          <div class="field"><label>Date</label><input type="date" name="date" required value="${today}"></div>
          <div class="field"><label>Type</label>
            <select name="type" required>
              <option value="Entrée">Entrée (réapprovisionnement)</option>
              <option value="Sortie">Sortie (livraison, usage interne...)</option>
            </select>
          </div>
        </div>
        <div class="row-2">
          <div class="field">
            <label>Article</label>
            <select name="articleId" required>
              <option value="">— choisir —</option>
              ${produits.map((a) => `<option value="${a.id}">${escapeHtml(a.reference)} — ${escapeHtml(a.designation)}</option>`).join("")}
            </select>
          </div>
          <div class="field"><label>Quantité</label><input type="number" name="quantite" min="1" step="1" required></div>
        </div>
        <div class="field"><label>Référence document (facture, bon de commande...)</label><input name="refDocument"></div>
        <div class="field"><label>Commentaire</label><textarea name="commentaire"></textarea></div>
        <div class="actions">
          <button class="btn gold" type="submit">Enregistrer le mouvement</button>
          <a class="btn secondary" href="/stock">Annuler</a>
        </div>
      </form>
    </div>
  `;
}

module.exports = { stockOverviewBody, stockFormBody };
