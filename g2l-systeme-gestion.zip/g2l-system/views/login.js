const { authLayout } = require("./layout");

// Le rappel des comptes de demonstration ne doit jamais s'afficher sur une
// instance accessible depuis Internet.
const PRODUCTION = process.env.NODE_ENV === "production";
const SITE_URL = process.env.SITE_URL || "https://g2l-ci.com";

function loginView({ flash }) {
  const hint = PRODUCTION
    ? `<div class="auth-hint">
         Identifiants oubliés ? Contactez la direction à <strong>contact@g2l-ci.com</strong>.
       </div>`
    : `<div class="auth-hint">
         Compte de démonstration : <strong>gerant@g2l-ci.com</strong> / <strong>G2L2026!</strong><br>
         (voir README.md pour la liste complète des comptes créés par direction — à changer avant tout usage réel)
       </div>`;

  const body = `
    <form method="POST" action="/login">
      <div class="field">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required autofocus placeholder="prenom@g2l-ci.com">
      </div>
      <div class="field">
        <label for="password">Mot de passe</label>
        <input type="password" id="password" name="password" required>
      </div>
      <button class="btn gold" type="submit">Se connecter</button>
    </form>
    ${hint}
    <div class="auth-back">
      <a href="${SITE_URL}">← Retour au site g2l-ci.com</a>
    </div>
  `;
  return authLayout({ title: "Connexion", body, flash });
}

module.exports = { loginView };
