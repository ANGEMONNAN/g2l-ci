const { escapeHtml } = require("../lib/helpers");

function clientsListBody({ items }) {
  const rows = items
    .map(
      (c) => `<tr>
        <td>${escapeHtml(c.code)}</td>
        <td>${escapeHtml(c.nom)}</td>
        <td>${escapeHtml(c.adresse)}</td>
        <td>${escapeHtml(c.telephone)}</td>
        <td>${escapeHtml(c.email)}</td>
        <td><a class="btn secondary small" href="/clients/${c.id}/edit">Modifier</a></td>
      </tr>`
    )
    .join("");
  return `
    <div class="page-head">
      <div>
        <p class="eyebrow">G2L — Clients</p>
        <h1>Répertoire clients</h1>
        <p>${items.length} client(s) enregistré(s).</p>
      </div>
      <a class="btn gold" href="/clients/new">+ Nouveau client</a>
    </div>
    <div class="card">
      <table class="data">
        <thead><tr><th>Code</th><th>Raison sociale / Nom</th><th>Adresse</th><th>Téléphone</th><th>Email</th><th></th></tr></thead>
        <tbody>${rows || `<tr class="empty-row"><td colspan="6">Aucun client — commence par en créer un.</td></tr>`}</tbody>
      </table>
    </div>
  `;
}

function clientFormBody({ client, isEdit }) {
  const c = client || {};
  return `
    <div class="page-head"><div><p class="eyebrow">G2L — Clients</p><h1>${isEdit ? "Modifier le client" : "Nouveau client"}</h1></div></div>
    <div class="card">
      <form class="stack" method="POST" action="${isEdit ? `/clients/${c.id}/edit` : "/clients/new"}">
        <div class="row-2">
          <div class="field"><label>Code client</label><input name="code" required value="${escapeHtml(c.code || "")}" placeholder="CLI-001"></div>
          <div class="field"><label>Raison sociale / Nom</label><input name="nom" required value="${escapeHtml(c.nom || "")}"></div>
        </div>
        <div class="field"><label>Adresse</label><input name="adresse" value="${escapeHtml(c.adresse || "")}"></div>
        <div class="row-2">
          <div class="field"><label>Téléphone</label><input name="telephone" value="${escapeHtml(c.telephone || "")}"></div>
          <div class="field"><label>Email</label><input type="email" name="email" value="${escapeHtml(c.email || "")}"></div>
        </div>
        <div class="field"><label>Notes</label><textarea name="notes">${escapeHtml(c.notes || "")}</textarea></div>
        <div class="actions">
          <button class="btn gold" type="submit">Enregistrer</button>
          <a class="btn secondary" href="/clients">Annuler</a>
        </div>
      </form>
    </div>
  `;
}

module.exports = { clientsListBody, clientFormBody };
