const { escapeHtml, fmtCurrency, fmtDate } = require("../lib/helpers");
const { lineItemsEditor } = require("./lineform");

const STATUT_LABEL = { en_attente: "En attente", accepte: "Accepté", refuse: "Refusé" };
const STATUT_CLASS = { en_attente: "attente", accepte: "accepte", refuse: "refuse" };

function devisListBody({ items }) {
  const rows = items
    .map(
      (d) => `<tr>
        <td><a href="/devis/${d.id}">${escapeHtml(d.numero)}</a></td>
        <td>${fmtDate(d.date)}</td>
        <td>${escapeHtml(d.clientNom)}</td>
        <td class="num">${fmtCurrency(d.ttc)}</td>
        <td><span class="badge ${STATUT_CLASS[d.statut]}">${STATUT_LABEL[d.statut]}</span></td>
        <td><a class="btn secondary small" href="/devis/${d.id}">Voir</a></td>
      </tr>`
    )
    .join("");
  return `
    <div class="page-head">
      <div><p class="eyebrow">G2L — Devis</p><h1>Devis</h1><p>${items.length} devis enregistré(s).</p></div>
      <a class="btn gold" href="/devis/new">+ Nouveau devis</a>
    </div>
    <div class="card">
      <table class="data">
        <thead><tr><th>N°</th><th>Date</th><th>Client</th><th class="num">Total TTC</th><th>Statut</th><th></th></tr></thead>
        <tbody>${rows || `<tr class="empty-row"><td colspan="6">Aucun devis pour l'instant.</td></tr>`}</tbody>
      </table>
    </div>
  `;
}

function devisFormBody({ clients, catalogue, numero, today }) {
  return `
    <div class="page-head"><div><p class="eyebrow">G2L — Devis</p><h1>Nouveau devis</h1><p>Numéro suggéré : ${numero}</p></div></div>
    <div class="card">
      <form class="stack" method="POST" action="/devis/new" style="max-width:820px;">
        <div class="row-3">
          <div class="field"><label>Numéro</label><input name="numero" required value="${numero}"></div>
          <div class="field"><label>Date</label><input type="date" name="date" required value="${today}"></div>
          <div class="field"><label>Taux TVA (%)</label><input type="number" id="tauxTva-devis" name="tauxTvaPct" step="0.1" min="0" value="18"></div>
        </div>
        <div class="field">
          <label>Client</label>
          <select name="clientId" required>
            <option value="">— choisir un client —</option>
            ${clients.map((c) => `<option value="${c.id}">${escapeHtml(c.code)} — ${escapeHtml(c.nom)}</option>`).join("")}
          </select>
        </div>

        ${lineItemsEditor({ catalogue, existingLignes: null, formIdPrefix: "devis" })}

        <div class="actions">
          <button class="btn gold" type="submit">Créer le devis</button>
          <a class="btn secondary" href="/devis">Annuler</a>
        </div>
      </form>
    </div>
  `;
}

function devisViewBody({ devis, canEditStatut }) {
  const rows = devis.lignes
    .map(
      (l) => `<tr><td>${escapeHtml(l.designation)}</td><td class="num">${l.quantite}</td><td class="num">${fmtCurrency(l.prixUnitaire)}</td><td class="num">${fmtCurrency(l.quantite * l.prixUnitaire)}</td></tr>`
    )
    .join("");

  return `
    <div class="page-head">
      <div>
        <p class="eyebrow">G2L — Devis ${escapeHtml(devis.numero)}</p>
        <h1>${escapeHtml(devis.clientNom)}</h1>
        <p>Émis le ${fmtDate(devis.date)} — <span class="badge ${STATUT_CLASS[devis.statut]}">${STATUT_LABEL[devis.statut]}</span></p>
      </div>
      <a class="btn secondary" href="/devis">← Retour</a>
    </div>

    <div class="card">
      <h2>Lignes</h2>
      <table class="data">
        <thead><tr><th>Désignation</th><th class="num">Qté</th><th class="num">PU HT</th><th class="num">Montant HT</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="totals-box" style="margin-top:16px;">
        <div class="line"><span>Sous-total HT</span><span>${fmtCurrency(devis.sousTotal)}</span></div>
        <div class="line"><span>TVA (${(devis.tauxTva * 100).toFixed(1)}%)</span><span>${fmtCurrency(devis.tva)}</span></div>
        <div class="line total"><span>Total TTC</span><span>${fmtCurrency(devis.ttc)}</span></div>
      </div>
    </div>

    <div class="card">
      <h2>Statut</h2>
      <form method="POST" action="/devis/${devis.id}/statut" class="row-2" style="align-items:end;max-width:420px;">
        <div class="field">
          <label>Changer le statut</label>
          <select name="statut">
            <option value="en_attente" ${devis.statut === "en_attente" ? "selected" : ""}>En attente</option>
            <option value="accepte" ${devis.statut === "accepte" ? "selected" : ""}>Accepté</option>
            <option value="refuse" ${devis.statut === "refuse" ? "selected" : ""}>Refusé</option>
          </select>
        </div>
        <button class="btn secondary" type="submit">Mettre à jour</button>
      </form>
      ${
        devis.statut === "accepte" && !devis.factureId
          ? `<form method="POST" action="/devis/${devis.id}/convertir" style="margin-top:14px;"><button class="btn gold" type="submit">Convertir en facture →</button></form>`
          : ""
      }
      ${devis.factureId ? `<p class="section-note">Déjà converti en facture <a href="/factures/${devis.factureId}">${escapeHtml(devis.factureNumero || "")}</a>.</p>` : ""}
    </div>
  `;
}

module.exports = { devisListBody, devisFormBody, devisViewBody, STATUT_LABEL, STATUT_CLASS };
