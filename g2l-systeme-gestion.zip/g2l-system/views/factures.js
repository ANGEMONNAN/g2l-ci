const { escapeHtml, fmtCurrency, fmtDate, todayIso } = require("../lib/helpers");
const { lineItemsEditor } = require("./lineform");

const STATUT_CLASS = { "Payée": "paid", "En retard": "retard", "En attente": "attente" };

function facturesListBody({ items }) {
  const rows = items
    .map(
      (f) => `<tr>
        <td><a href="/factures/${f.id}">${escapeHtml(f.numero)}</a></td>
        <td>${fmtDate(f.date)}</td>
        <td>${fmtDate(f.echeance)}</td>
        <td>${escapeHtml(f.clientNom)}</td>
        <td class="num">${fmtCurrency(f.ttc)}</td>
        <td><span class="badge ${STATUT_CLASS[f.statut]}">${f.statut}</span></td>
        <td><a class="btn secondary small" href="/factures/${f.id}">Voir</a></td>
      </tr>`
    )
    .join("");
  return `
    <div class="page-head">
      <div><p class="eyebrow">G2L — Factures</p><h1>Factures</h1><p>${items.length} facture(s) émise(s).</p></div>
      <a class="btn gold" href="/factures/new">+ Nouvelle facture</a>
    </div>
    <div class="card">
      <table class="data">
        <thead><tr><th>N°</th><th>Date</th><th>Échéance</th><th>Client</th><th class="num">Total TTC</th><th>Statut</th><th></th></tr></thead>
        <tbody>${rows || `<tr class="empty-row"><td colspan="7">Aucune facture pour l'instant.</td></tr>`}</tbody>
      </table>
    </div>
  `;
}

function facturesFormBody({ clients, catalogue, numero, today }) {
  const echeanceDefault = new Date();
  echeanceDefault.setDate(echeanceDefault.getDate() + 30);
  return `
    <div class="page-head"><div><p class="eyebrow">G2L — Factures</p><h1>Nouvelle facture</h1><p>Numéro suggéré : ${numero}</p></div></div>
    <div class="card">
      <form class="stack" method="POST" action="/factures/new" style="max-width:820px;">
        <div class="row-3">
          <div class="field"><label>Numéro</label><input name="numero" required value="${numero}"></div>
          <div class="field"><label>Date d'émission</label><input type="date" name="date" required value="${today}"></div>
          <div class="field"><label>Échéance</label><input type="date" name="echeance" required value="${echeanceDefault.toISOString().slice(0, 10)}"></div>
        </div>
        <div class="row-2">
          <div class="field">
            <label>Client</label>
            <select name="clientId" required>
              <option value="">— choisir un client —</option>
              ${clients.map((c) => `<option value="${c.id}">${escapeHtml(c.code)} — ${escapeHtml(c.nom)}</option>`).join("")}
            </select>
          </div>
          <div class="field"><label>Taux TVA (%)</label><input type="number" id="tauxTva-facture" name="tauxTvaPct" step="0.1" min="0" value="18"></div>
        </div>

        ${lineItemsEditor({ catalogue, existingLignes: null, formIdPrefix: "facture" })}

        <div class="actions">
          <button class="btn gold" type="submit">Créer la facture</button>
          <a class="btn secondary" href="/factures">Annuler</a>
        </div>
      </form>
    </div>
  `;
}

function factureViewBody({ facture }) {
  const rows = facture.lignes
    .map(
      (l) => `<tr><td>${escapeHtml(l.designation)}</td><td class="num">${l.quantite}</td><td class="num">${fmtCurrency(l.prixUnitaire)}</td><td class="num">${fmtCurrency(l.quantite * l.prixUnitaire)}</td></tr>`
    )
    .join("");

  return `
    <div class="page-head">
      <div>
        <p class="eyebrow">G2L — Facture ${escapeHtml(facture.numero)}</p>
        <h1>${escapeHtml(facture.clientNom)}</h1>
        <p>Émise le ${fmtDate(facture.date)} — échéance ${fmtDate(facture.echeance)} — <span class="badge ${STATUT_CLASS[facture.statut]}">${facture.statut}</span></p>
      </div>
      <a class="btn secondary" href="/factures">← Retour</a>
    </div>

    <div class="card">
      <h2>Lignes</h2>
      <table class="data">
        <thead><tr><th>Désignation</th><th class="num">Qté</th><th class="num">PU HT</th><th class="num">Montant HT</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="totals-box" style="margin-top:16px;">
        <div class="line"><span>Sous-total HT</span><span>${fmtCurrency(facture.sousTotal)}</span></div>
        <div class="line"><span>TVA (${(facture.tauxTva * 100).toFixed(1)}%)</span><span>${fmtCurrency(facture.tva)}</span></div>
        <div class="line total"><span>Total TTC</span><span>${fmtCurrency(facture.ttc)}</span></div>
      </div>
    </div>

    <div class="card">
      <h2>Règlement</h2>
      ${
        facture.datePaiement
          ? `<p class="stat-inline">Payée le ${fmtDate(facture.datePaiement)}.</p>`
          : `<form method="POST" action="/factures/${facture.id}/paiement" class="row-2" style="align-items:end;max-width:420px;">
              <div class="field"><label>Date de paiement</label><input type="date" name="datePaiement" value="${todayIso()}" required></div>
              <button class="btn gold" type="submit">Marquer comme payée</button>
            </form>`
      }
    </div>
  `;
}

module.exports = { facturesListBody, facturesFormBody, factureViewBody };
