const { escapeHtml, fmtCurrency } = require("../lib/helpers");
const { statutStock, computeStock } = require("../lib/business");

function badgeClass(statut) {
  if (statut === "OK") return "ok";
  if (statut === "À réapprovisionner") return "danger";
  return "muted";
}

function catalogueListBody({ items }) {
  const rows = items
    .map((a) => {
      const statut = statutStock(a);
      const stock = a.type === "Produit" ? computeStock(a.id) : "—";
      return `<tr>
        <td>${escapeHtml(a.reference)}</td>
        <td>${escapeHtml(a.designation)}</td>
        <td>${escapeHtml(a.type)}</td>
        <td>${escapeHtml(a.unite)}</td>
        <td class="num">${fmtCurrency(a.prixUnitaire)}</td>
        <td class="num">${stock}</td>
        <td><span class="badge ${badgeClass(statut)}">${statut}</span></td>
        <td><a class="btn secondary small" href="/catalogue/${a.id}/edit">Modifier</a></td>
      </tr>`;
    })
    .join("");

  return `
    <div class="page-head">
      <div>
        <p class="eyebrow">G2L — Catalogue</p>
        <h1>Produits &amp; services</h1>
        <p>${items.length} article(s) référencé(s).</p>
      </div>
      <a class="btn gold" href="/catalogue/new">+ Nouvel article</a>
    </div>
    <div class="card">
      <table class="data">
        <thead><tr><th>Référence</th><th>Désignation</th><th>Type</th><th>Unité</th><th class="num">Prix HT</th><th class="num">Stock</th><th>Statut</th><th></th></tr></thead>
        <tbody>${rows || `<tr class="empty-row"><td colspan="8">Aucun article — commence par en créer un.</td></tr>`}</tbody>
      </table>
    </div>
  `;
}

function catalogueFormBody({ article, isEdit }) {
  const a = article || {};
  return `
    <div class="page-head">
      <div>
        <p class="eyebrow">G2L — Catalogue</p>
        <h1>${isEdit ? "Modifier l'article" : "Nouvel article"}</h1>
      </div>
    </div>
    <div class="card">
      <form class="stack" method="POST" action="${isEdit ? `/catalogue/${a.id}/edit` : "/catalogue/new"}">
        <div class="row-2">
          <div class="field"><label>Référence</label><input name="reference" required value="${escapeHtml(a.reference || "")}"></div>
          <div class="field"><label>Type</label>
            <select name="type" id="type-select">
              <option value="Service" ${a.type === "Service" ? "selected" : ""}>Service</option>
              <option value="Produit" ${a.type === "Produit" ? "selected" : ""}>Produit</option>
            </select>
          </div>
        </div>
        <div class="field"><label>Désignation</label><input name="designation" required value="${escapeHtml(a.designation || "")}"></div>
        <div class="row-2">
          <div class="field"><label>Unité</label><input name="unite" value="${escapeHtml(a.unite || "")}" placeholder="Unité, Mois, Jour..."></div>
          <div class="field"><label>Prix unitaire HT (F CFA)</label><input type="number" step="1" min="0" name="prixUnitaire" required value="${a.prixUnitaire ?? ""}"></div>
        </div>
        <div class="row-2" id="stock-fields" style="${a.type === "Service" ? "opacity:.5" : ""}">
          <div class="field"><label>Stock initial</label><input type="number" step="1" name="stockInitial" value="${a.stockInitial ?? ""}"></div>
          <div class="field"><label>Seuil d'alerte</label><input type="number" step="1" name="seuilAlerte" value="${a.seuilAlerte ?? ""}"></div>
        </div>
        <p class="section-note">Le stock initial ne sert qu'à la création : ensuite, utilise la page Stock pour enregistrer les entrées/sorties — le stock actuel se recalcule tout seul.</p>
        <div class="actions">
          <button class="btn gold" type="submit">Enregistrer</button>
          <a class="btn secondary" href="/catalogue">Annuler</a>
        </div>
      </form>
    </div>
    <script>
      document.getElementById('type-select').addEventListener('change', function() {
        document.getElementById('stock-fields').style.opacity = this.value === 'Produit' ? '1' : '.5';
      });
    </script>
  `;
}

module.exports = { catalogueListBody, catalogueFormBody };
