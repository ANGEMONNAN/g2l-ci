# G2L — Système de gestion interne

Application web interne pour Global Leading Group (G2L) : authentification par
direction, tableau de bord, devis, factures, catalogue & stock, clients, et
demandes d'achat inter-directions.

Construite en **Node.js pur, sans aucune dépendance externe** (pas de
`npm install` requis) : cela la rend simple à héberger sur n'importe quel
serveur qui exécute Node.js, sans risque de rupture liée à des paquets tiers.

## Démarrage rapide

Prérequis : Node.js version 18 ou plus récente (déjà présent sur la plupart
des hébergeurs modernes ; vérifier avec `node -v`).

```bash
cd g2l-system
npm run seed     # crée les 7 comptes + des données d'exemple (une seule fois)
npm start        # démarre le serveur sur http://localhost:3000
```

Ouvrir ensuite `http://localhost:3000` (ou l'adresse du serveur si hébergé
ailleurs) et se connecter avec l'un des comptes ci-dessous.

`npm run seed` ne fait rien si des utilisateurs existent déjà — il est donc
sûr de le laisser dans un script de démarrage. Pour repartir d'une base
vierge, supprimer le contenu du dossier `data/` puis relancer `npm run seed`.

## Comptes par défaut

Un compte par direction, comme défini dans les fiches de poste G2L. Tous les
comptes utilisent le même mot de passe par défaut :

**Mot de passe par défaut : `G2L2026!`**

| Direction | Email |
|---|---|
| Direction Générale (Gérant) | gerant@g2l.ci |
| DSI | dsi@g2l.ci |
| DCF | dcf@g2l.ci |
| Opérations | operations@g2l.ci |
| Juridique | juridique@g2l.ci |
| Conseil, Stratégie & Formation | conseil@g2l.ci |
| Achats & Équipements | achats@g2l.ci |

**Important — avant toute utilisation réelle :** chaque utilisateur doit se
connecter et changer son mot de passe depuis *Mon compte* (menu en bas de la
barre latérale). Ne pas garder le mot de passe par défaut au-delà de la phase
de test.

## Fonctionnalités par module

**Tableau de bord** — indicateurs clés en un coup d'œil : chiffre d'affaires
facturé et encaissé, valeur du stock, alertes de stock bas, demandes d'achat
en attente, prochains numéros de devis/facture. Le contenu s'adapte selon ce
qui nécessite l'attention de l'utilisateur.

**Devis** — création avec lignes multiples (article du catalogue ou saisie
libre), calcul automatique des totaux HT/TVA/TTC, suivi de statut (brouillon,
envoyé, accepté, refusé), et conversion en un clic d'un devis accepté vers une
facture liée.

**Factures** — mêmes lignes dynamiques que les devis, échéance de paiement,
enregistrement de la date de paiement, statut calculé automatiquement (payée /
en attente / en retard selon l'échéance).

**Catalogue** — produits et services avec référence, désignation, prix
unitaire ; les produits ont un stock initial et un seuil d'alerte, les
services n'ont pas de notion de stock.

**Stock** — mouvements d'entrée/sortie horodatés, quantité en stock calculée
automatiquement à partir des mouvements, indicateur visuel quand le stock
passe sous le seuil d'alerte.

**Clients** — fiche par client (coordonnées, notes) utilisée dans les devis et
factures.

**Demandes d'achat** — n'importe quelle direction peut soumettre une demande
(article, quantité, justification, urgence) ; seule la Direction Générale peut
approuver ou rejeter. C'est le premier brique du volet « système interactif
entre directions » demandé — d'autres types de demandes/circuits de validation
pourront suivre le même modèle.

## Stockage des données

Pas de base de données à installer : chaque type de donnée (utilisateurs,
clients, catalogue, devis, factures, mouvements de stock, demandes d'achat)
est stocké dans un fichier JSON séparé sous `data/`. C'est volontairement
simple pour la phase actuelle — largement suffisant pour l'usage d'une petite
équipe, et lisible/réparable à la main si besoin.

**Sauvegarde :** copier le dossier `data/` régulièrement (ou le mettre dans un
dossier synchronisé type OneDrive/Google Drive côté serveur) suffit à
sauvegarder l'intégralité des données de l'application.

## Déploiement — passer du test à un usage réel par l'équipe

Cette version fonctionne actuellement uniquement en local, dans
l'environnement de test. Pour que toute l'équipe y accède, il faut
l'installer sur un serveur qui reste allumé en permanence et exécute Node.js.
Options courantes, du plus simple au plus autonome :

- **Hébergeur Node géré** (Render, Railway, ou équivalent) : on y dépose le
  code, l'hébergeur exécute `npm start` et fournit une adresse web accessible
  depuis n'importe où. Le plus rapide à mettre en place.
- **VPS (serveur privé virtuel)** avec Node.js installé, l'application
  maintenue active en arrière-plan (par exemple avec l'outil `pm2`), et un
  serveur web (nginx) devant pour gérer l'adresse et le HTTPS. Demande un peu
  plus de configuration mais donne un contrôle complet.

**Point d'attention :** un hébergement mutualisé classique orienté PHP (le
type d'offre la plus répandue et la moins chère chez beaucoup
d'hébergeurs) **ne convient pas tel quel**, car cette application est écrite
en Node.js et non en PHP. Il faut spécifiquement une offre qui exécute des
applications Node.js.

Une fois l'hébergement choisi, deux réglages supplémentaires seront à faire :
un nom de domaine/sous-domaine pointant vers le serveur, et HTTPS (souvent
automatique chez les hébergeurs Node gérés).

## Limites connues (à garder à l'esprit pour l'instant)

- **Sessions en mémoire** : si le serveur redémarre (mise à jour, panne,
  redéploiement), tout le monde est déconnecté et doit se reconnecter. Sans
  conséquence sur les données, juste une gêne mineure.
- **Un seul niveau d'accès administrateur** : la Direction Générale valide les
  demandes d'achat ; les autres droits (qui peut voir/modifier quoi) sont
  volontairement simples pour l'instant et pourront être affinés selon les
  besoins réels observés à l'usage.

## Feuille de route — non inclus dans cette version

**Comptabilité (écritures, bilans, états financiers SYSCOHADA)** a été
délibérément laissée de côté dans cette première version. C'est un domaine à
part entière — le plan comptable et les règles débit/crédit OHADA doivent être
implémentés avec rigueur, sans quoi les chiffres produits seraient trompeurs.
Cela mérite un chantier dédié plutôt qu'un ajout précipité, une fois que le
reste de l'application aura fait ses preuves à l'usage.

D'autres extensions (nouveaux types de demandes inter-directions, export
PDF des devis/factures directement depuis l'application, rôles d'accès plus
fins, etc.) pourront être ajoutées au même socle au fil des besoins.

---

*G2L — Global Leading Group.*
