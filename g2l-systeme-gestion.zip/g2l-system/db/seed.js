// Seeds initial users + example data. Safe to re-run: skips if users already exist.
const Store = require("../lib/store");
const { hashPassword } = require("../lib/auth");
const { ROLE_ORDER, roleLabel } = require("../lib/roles");

const DEFAULT_PASSWORD = "G2L2026!";

const USERS = [
  { role: "gerant", nom: "Béda Ange-Gabriel Monnan", email: "gerant@g2l-ci.com" },
  { role: "dsi", nom: "Responsable DSI", email: "dsi@g2l-ci.com" },
  { role: "dcf", nom: "Responsable DCF", email: "dcf@g2l-ci.com" },
  { role: "operations", nom: "Responsable Opérations", email: "operations@g2l-ci.com" },
  { role: "juridique", nom: "Responsable Juridique", email: "juridique@g2l-ci.com" },
  { role: "conseil", nom: "Chargé(e) de Conseil", email: "conseil@g2l-ci.com" },
  { role: "achats", nom: "Responsable Achats & Équipements", email: "achats@g2l-ci.com" },
];

function seed() {
  if (Store.users.all().length > 0) {
    console.log("Des utilisateurs existent déjà — seed ignoré (supprime data/*.json pour repartir de zéro).");
    return;
  }

  const createdUsers = USERS.map((u) =>
    Store.users.insert({ ...u, passwordHash: hashPassword(DEFAULT_PASSWORD) })
  );
  const gerant = createdUsers[0];

  const client = Store.clients.insert({
    code: "CLI-001",
    nom: "[Exemple] Société ABC",
    adresse: "Cocody, Abidjan",
    telephone: "+225 XX XX XX XX XX",
    email: "contact@abc-exemple.ci",
    notes: "Client exemple — à remplacer",
  });

  const catalogueItems = [
    { reference: "REF-DSI", designation: "Direction Systèmes d'Information (mensuel)", type: "Service", unite: "Mois", prixUnitaire: 450000, stockInitial: "", seuilAlerte: "" },
    { reference: "REF-DCF", designation: "Direction Comptable et Financière (mensuel)", type: "Service", unite: "Mois", prixUnitaire: 450000, stockInitial: "", seuilAlerte: "" },
    { reference: "REF-CONSEIL", designation: "Journée de conseil / accompagnement", type: "Service", unite: "Jour", prixUnitaire: 150000, stockInitial: "", seuilAlerte: "" },
    { reference: "REF-PC-001", designation: "Ordinateur portable professionnel", type: "Produit", unite: "Unité", prixUnitaire: 350000, stockInitial: 10, seuilAlerte: 3 },
  ];
  const catalogue = catalogueItems.map((c) => Store.catalogue.insert(c));
  const pc = catalogue.find((c) => c.reference === "REF-PC-001");
  const dsi = catalogue.find((c) => c.reference === "REF-DSI");

  Store.mouvements.insert({ date: "2026-08-18", articleId: pc.id, type: "Sortie", quantite: 3, refDocument: "FACT-2026-001", commentaire: "Livraison client (exemple)", createdBy: gerant.id });
  Store.mouvements.insert({ date: "2026-08-20", articleId: pc.id, type: "Entrée", quantite: 5, refDocument: "Réappro fournisseur", commentaire: "Commande fournisseur (exemple)", createdBy: gerant.id });

  const devis = Store.devis.insert({
    numero: "DEVIS-2026-001",
    date: "2026-08-18",
    clientId: client.id,
    tauxTva: 0.18,
    statut: "accepte",
    factureId: null,
    createdBy: gerant.id,
    createdAt: new Date().toISOString(),
  });
  Store.devisLignes.insert({ devisId: devis.id, articleId: dsi.id, designation: dsi.designation, quantite: 1, prixUnitaire: dsi.prixUnitaire });
  Store.devisLignes.insert({ devisId: devis.id, articleId: pc.id, designation: pc.designation, quantite: 3, prixUnitaire: pc.prixUnitaire });

  const facture = Store.factures.insert({
    numero: "FACT-2026-001",
    date: "2026-08-18",
    echeance: "2026-09-17",
    clientId: client.id,
    tauxTva: 0.18,
    datePaiement: null,
    devisId: devis.id,
    createdBy: gerant.id,
    createdAt: new Date().toISOString(),
  });
  Store.factureLignes.insert({ factureId: facture.id, articleId: pc.id, designation: pc.designation, quantite: 3, prixUnitaire: pc.prixUnitaire });
  Store.devis.update(devis.id, { factureId: facture.id });

  Store.demandesAchat.insert({
    numero: "DA-2026-001",
    date: "2026-08-18",
    demandeurId: createdUsers.find((u) => u.role === "dsi").id,
    direction: "dsi",
    article: "2 imprimantes laser (exemple)",
    quantite: 2,
    justification: "Remplacement de matériel en panne — exemple",
    urgence: "Normale",
    statut: "en_attente",
    commentaireValidation: "",
    valideePar: null,
    dateValidation: null,
  });

  console.log("Seed terminé. Comptes créés (mot de passe par défaut pour tous : " + DEFAULT_PASSWORD + ") :");
  ROLE_ORDER.forEach((role) => {
    const u = createdUsers.find((x) => x.role === role);
    console.log(`  - ${roleLabel(role)} : ${u.email}`);
  });
}

seed();
