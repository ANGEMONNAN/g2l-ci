const http = require("http");
const fs = require("fs");
const path = require("path");
const { URL } = require("url");

const Router = require("./lib/router");
const Store = require("./lib/store");
const { parseCookies, getUserIdForToken, SESSION_COOKIE } = require("./lib/auth");

const router = new Router();
require("./routes/auth").register(router);
require("./routes/dashboard").register(router);
require("./routes/catalogue").register(router);
require("./routes/clients").register(router);
require("./routes/devis").register(router);
require("./routes/factures").register(router);
require("./routes/stock").register(router);
require("./routes/achats").register(router);
require("./routes/account").register(router);

const PUBLIC_DIR = path.join(__dirname, "public");
const MIME = {
  ".css": "text/css",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".js": "text/javascript",
  ".ico": "image/x-icon",
};

const PUBLIC_PATHS = new Set(["/login", "/logout"]);

function serveStatic(req, res, pathname) {
  const rel = pathname.replace(/^\/public\//, "");
  const filePath = path.join(PUBLIC_DIR, rel);
  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    res.end("Forbidden");
    return;
  }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end("Not found");
      return;
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream" });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  const parsed = new URL(req.url, "http://localhost");
  const pathname = parsed.pathname;

  if (pathname.startsWith("/public/")) {
    serveStatic(req, res, pathname);
    return;
  }

  req.query = Object.fromEntries(parsed.searchParams.entries());
  req.flash = req.query.msg ? { type: req.query.t || "info", message: req.query.msg } : null;

  const cookies = parseCookies(req);
  const token = cookies[SESSION_COOKIE];
  const userId = token ? getUserIdForToken(token) : null;
  req.user = userId ? Store.users.find(userId) : null;

  if (!req.user && !PUBLIC_PATHS.has(pathname)) {
    res.writeHead(302, { Location: "/login" });
    res.end();
    return;
  }
  if (req.user && (pathname === "/login")) {
    res.writeHead(302, { Location: "/" });
    res.end();
    return;
  }

  const match = router.match(req.method, pathname);
  if (!match) {
    res.writeHead(404, { "Content-Type": "text/html; charset=utf-8" });
    res.end("<h1>404</h1><p>Page introuvable. <a href='/'>Retour au tableau de bord</a></p>");
    return;
  }

  try {
    await match.handler(req, res, match.params);
  } catch (err) {
    console.error(err);
    res.writeHead(500, { "Content-Type": "text/html; charset=utf-8" });
    res.end(`<h1>Erreur serveur</h1><pre>${(err && err.stack) || err}</pre>`);
  }
});

// ---------------------------------------------------------------------------
// Garde-fou de mise en production : le mot de passe de démonstration ne doit
// jamais rester actif sur une instance accessible depuis Internet.
// ---------------------------------------------------------------------------
function checkDefaultPasswords() {
  const { verifyPassword } = require("./lib/auth");
  const DEFAULT = "G2L2026!";
  let comptes;
  try {
    comptes = Store.users.all().filter((u) => u.passwordHash && verifyPassword(DEFAULT, u.passwordHash));
  } catch (e) {
    return;
  }
  if (comptes.length === 0) return;
  const liste = comptes.map((u) => u.email || u.login || u.id).join(", ");
  if (process.env.NODE_ENV === "production") {
    console.error("ARRET — mot de passe par defaut encore actif sur : " + liste);
    console.error("Changez ces mots de passe avant d'exposer la plateforme sur Internet.");
    process.exit(1);
  }
  console.warn("AVERTISSEMENT — mot de passe par defaut encore actif sur : " + liste);
}

checkDefaultPasswords();

const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || "0.0.0.0";
server.listen(PORT, HOST, () => {
  console.log(`G2L — système de gestion démarré sur le port ${PORT}`);
});
