const Store = require("../lib/store");
const { renderPage, redirectWithFlash } = require("../lib/page");
const { parseBody } = require("../lib/body");
const { nextNumero, todayIso } = require("../lib/helpers");
const { factureWithTotals, clientNom } = require("../lib/business");
const { facturesListBody, facturesFormBody, factureViewBody } = require("../views/factures");

function asArray(v) {
  if (v === undefined) return [];
  return Array.isArray(v) ? v : [v];
}

function register(router) {
  router.get("/factures", async (req, res) => {
    const items = Store.factures
      .all()
      .map((f) => ({ ...factureWithTotals(f), clientNom: clientNom(f.clientId) }))
      .sort((a, b) => b.numero.localeCompare(a.numero));
    renderPage(res, { user: req.user, title: "Factures", active: "factures", flash: req.flash, body: facturesListBody({ items }) });
  });

  router.get("/factures/new", async (req, res) => {
    const clients = Store.clients.all().sort((a, b) => a.nom.localeCompare(b.nom));
    const catalogue = Store.catalogue.all().sort((a, b) => a.reference.localeCompare(b.reference));
    if (!clients.length || !catalogue.length) {
      return redirectWithFlash(res, "/factures", "Crée d'abord au moins un client et un article de catalogue.", "error");
    }
    const numero = nextNumero("FACT", Store.factures.all().map((f) => f.numero));
    renderPage(res, {
      user: req.user,
      title: "Nouvelle facture",
      active: "factures",
      flash: req.flash,
      body: facturesFormBody({ clients, catalogue, numero, today: todayIso() }),
    });
  });

  router.post("/factures/new", async (req, res) => {
    const b = await parseBody(req);
    const articleIds = asArray(b.articleId);
    const quantites = asArray(b.quantite);

    const facture = Store.factures.insert({
      numero: b.numero.trim(),
      date: b.date,
      echeance: b.echeance,
      clientId: b.clientId,
      tauxTva: Number(b.tauxTvaPct || 0) / 100,
      datePaiement: null,
      devisId: null,
      createdBy: req.user.id,
      createdAt: new Date().toISOString(),
    });

    articleIds.forEach((articleId, i) => {
      if (!articleId) return;
      const article = Store.catalogue.find(articleId);
      if (!article) return;
      Store.factureLignes.insert({
        factureId: facture.id,
        articleId,
        designation: article.designation,
        quantite: Number(quantites[i] || 0),
        prixUnitaire: Number(article.prixUnitaire),
      });
    });

    redirectWithFlash(res, `/factures/${facture.id}`, "Facture créée.");
  });

  router.get("/factures/:id", async (req, res, params) => {
    const raw = Store.factures.find(params.id);
    if (!raw) return redirectWithFlash(res, "/factures", "Facture introuvable.", "error");
    const facture = { ...factureWithTotals(raw), clientNom: clientNom(raw.clientId) };
    renderPage(res, { user: req.user, title: `Facture ${facture.numero}`, active: "factures", flash: req.flash, body: factureViewBody({ facture }) });
  });

  router.post("/factures/:id/paiement", async (req, res, params) => {
    const b = await parseBody(req);
    Store.factures.update(params.id, { datePaiement: b.datePaiement });
    redirectWithFlash(res, `/factures/${params.id}`, "Facture marquée comme payée.");
  });
}

module.exports = { register };
