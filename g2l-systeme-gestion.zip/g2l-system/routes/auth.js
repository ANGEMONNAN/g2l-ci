const Store = require("../lib/store");
const { verifyPassword, createSession, setSessionCookie, destroySession, parseCookies, SESSION_COOKIE, clearSessionCookie } = require("../lib/auth");
const { parseBody } = require("../lib/body");
const { loginView } = require("../views/login");

function register(router) {
  router.get("/login", async (req, res) => {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    res.end(loginView({ flash: req.flash }));
  });

  router.post("/login", async (req, res) => {
    const body = await parseBody(req);
    const email = (body.email || "").trim().toLowerCase();
    const user = Store.users.all().find((u) => u.email.toLowerCase() === email);
    if (!user || !verifyPassword(body.password || "", user.passwordHash)) {
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      res.end(loginView({ flash: { type: "error", message: "Email ou mot de passe incorrect." } }));
      return;
    }
    const token = createSession(user.id);
    setSessionCookie(res, token);
    res.writeHead(302, { Location: "/" });
    res.end();
  });

  router.get("/logout", async (req, res) => {
    const cookies = parseCookies(req);
    if (cookies[SESSION_COOKIE]) destroySession(cookies[SESSION_COOKIE]);
    clearSessionCookie(res);
    res.writeHead(302, { Location: "/login" });
    res.end();
  });
}

module.exports = { register };
