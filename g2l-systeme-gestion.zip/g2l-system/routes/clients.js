const Store = require("../lib/store");
const { renderPage, redirectWithFlash } = require("../lib/page");
const { parseBody } = require("../lib/body");
const { clientsListBody, clientFormBody } = require("../views/clients");

function register(router) {
  router.get("/clients", async (req, res) => {
    const items = Store.clients.all().sort((a, b) => a.code.localeCompare(b.code));
    renderPage(res, { user: req.user, title: "Clients", active: "clients", flash: req.flash, body: clientsListBody({ items }) });
  });

  router.get("/clients/new", async (req, res) => {
    renderPage(res, { user: req.user, title: "Nouveau client", active: "clients", flash: req.flash, body: clientFormBody({ isEdit: false }) });
  });

  router.post("/clients/new", async (req, res) => {
    const b = await parseBody(req);
    Store.clients.insert({
      code: b.code.trim(),
      nom: b.nom.trim(),
      adresse: b.adresse || "",
      telephone: b.telephone || "",
      email: b.email || "",
      notes: b.notes || "",
    });
    redirectWithFlash(res, "/clients", "Client ajouté.");
  });

  router.get("/clients/:id/edit", async (req, res, params) => {
    const client = Store.clients.find(params.id);
    if (!client) return redirectWithFlash(res, "/clients", "Client introuvable.", "error");
    renderPage(res, { user: req.user, title: "Modifier le client", active: "clients", flash: req.flash, body: clientFormBody({ client, isEdit: true }) });
  });

  router.post("/clients/:id/edit", async (req, res, params) => {
    const b = await parseBody(req);
    Store.clients.update(params.id, {
      code: b.code.trim(),
      nom: b.nom.trim(),
      adresse: b.adresse || "",
      telephone: b.telephone || "",
      email: b.email || "",
      notes: b.notes || "",
    });
    redirectWithFlash(res, "/clients", "Client mis à jour.");
  });
}

module.exports = { register };
