const Store = require("../lib/store");
const { renderPage, redirectWithFlash } = require("../lib/page");
const { parseBody } = require("../lib/body");
const { nextNumero, todayIso } = require("../lib/helpers");
const { roleLabel } = require("../lib/roles");
const { achatsListBody, achatFormBody } = require("../views/achats");

function register(router) {
  router.get("/achats", async (req, res) => {
    const items = Store.demandesAchat
      .all()
      .map((d) => {
        const demandeur = Store.users.find(d.demandeurId);
        return { ...d, directionLabel: roleLabel(d.direction), demandeurNom: demandeur ? demandeur.nom : "?" };
      })
      .sort((a, b) => b.numero.localeCompare(a.numero));
    renderPage(res, {
      user: req.user,
      title: "Demandes d'achat",
      active: "achats",
      flash: req.flash,
      body: achatsListBody({ items, isGerant: req.user.role === "gerant" }),
    });
  });

  router.get("/achats/new", async (req, res) => {
    const numero = nextNumero("DA", Store.demandesAchat.all().map((d) => d.numero));
    renderPage(res, { user: req.user, title: "Nouvelle demande d'achat", active: "achats", flash: req.flash, body: achatFormBody({ numero, today: todayIso() }) });
  });

  router.post("/achats/new", async (req, res) => {
    const b = await parseBody(req);
    Store.demandesAchat.insert({
      numero: b.numero.trim(),
      date: b.date,
      demandeurId: req.user.id,
      direction: req.user.role,
      article: b.article.trim(),
      quantite: Number(b.quantite || 1),
      justification: b.justification || "",
      urgence: b.urgence || "Normale",
      statut: "en_attente",
      commentaireValidation: "",
      valideePar: null,
      dateValidation: null,
    });
    redirectWithFlash(res, "/achats", "Demande d'achat envoyée.");
  });

  function requireGerant(req, res) {
    if (req.user.role !== "gerant") {
      redirectWithFlash(res, "/achats", "Seule la Direction Générale peut valider ou rejeter une demande.", "error");
      return false;
    }
    return true;
  }

  router.post("/achats/:id/valider", async (req, res, params) => {
    if (!requireGerant(req, res)) return;
    Store.demandesAchat.update(params.id, { statut: "approuvee", valideePar: req.user.id, dateValidation: todayIso() });
    redirectWithFlash(res, "/achats", "Demande approuvée.");
  });

  router.post("/achats/:id/rejeter", async (req, res, params) => {
    if (!requireGerant(req, res)) return;
    Store.demandesAchat.update(params.id, { statut: "rejetee", valideePar: req.user.id, dateValidation: todayIso() });
    redirectWithFlash(res, "/achats", "Demande rejetée.", "info");
  });
}

module.exports = { register };
