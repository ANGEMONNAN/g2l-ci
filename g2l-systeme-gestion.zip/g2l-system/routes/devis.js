const Store = require("../lib/store");
const { renderPage, redirectWithFlash } = require("../lib/page");
const { parseBody } = require("../lib/body");
const { nextNumero, todayIso } = require("../lib/helpers");
const { devisWithTotals, clientNom } = require("../lib/business");
const { devisListBody, devisFormBody, devisViewBody } = require("../views/devis");

function asArray(v) {
  if (v === undefined) return [];
  return Array.isArray(v) ? v : [v];
}

function register(router) {
  router.get("/devis", async (req, res) => {
    const items = Store.devis
      .all()
      .map((d) => ({ ...devisWithTotals(d), clientNom: clientNom(d.clientId) }))
      .sort((a, b) => b.numero.localeCompare(a.numero));
    renderPage(res, { user: req.user, title: "Devis", active: "devis", flash: req.flash, body: devisListBody({ items }) });
  });

  router.get("/devis/new", async (req, res) => {
    const clients = Store.clients.all().sort((a, b) => a.nom.localeCompare(b.nom));
    const catalogue = Store.catalogue.all().sort((a, b) => a.reference.localeCompare(b.reference));
    if (!clients.length || !catalogue.length) {
      return redirectWithFlash(res, "/devis", "Crée d'abord au moins un client et un article de catalogue.", "error");
    }
    const numero = nextNumero("DEVIS", Store.devis.all().map((d) => d.numero));
    renderPage(res, {
      user: req.user,
      title: "Nouveau devis",
      active: "devis",
      flash: req.flash,
      body: devisFormBody({ clients, catalogue, numero, today: todayIso() }),
    });
  });

  router.post("/devis/new", async (req, res) => {
    const b = await parseBody(req);
    const articleIds = asArray(b.articleId);
    const quantites = asArray(b.quantite);

    const devis = Store.devis.insert({
      numero: b.numero.trim(),
      date: b.date,
      clientId: b.clientId,
      tauxTva: Number(b.tauxTvaPct || 0) / 100,
      statut: "en_attente",
      factureId: null,
      createdBy: req.user.id,
      createdAt: new Date().toISOString(),
    });

    articleIds.forEach((articleId, i) => {
      if (!articleId) return;
      const article = Store.catalogue.find(articleId);
      if (!article) return;
      Store.devisLignes.insert({
        devisId: devis.id,
        articleId,
        designation: article.designation,
        quantite: Number(quantites[i] || 0),
        prixUnitaire: Number(article.prixUnitaire),
      });
    });

    redirectWithFlash(res, `/devis/${devis.id}`, "Devis créé.");
  });

  router.get("/devis/:id", async (req, res, params) => {
    const raw = Store.devis.find(params.id);
    if (!raw) return redirectWithFlash(res, "/devis", "Devis introuvable.", "error");
    const devis = { ...devisWithTotals(raw), clientNom: clientNom(raw.clientId) };
    if (devis.factureId) {
      const f = Store.factures.find(devis.factureId);
      devis.factureNumero = f ? f.numero : null;
    }
    renderPage(res, { user: req.user, title: `Devis ${devis.numero}`, active: "devis", flash: req.flash, body: devisViewBody({ devis }) });
  });

  router.post("/devis/:id/statut", async (req, res, params) => {
    const b = await parseBody(req);
    Store.devis.update(params.id, { statut: b.statut });
    redirectWithFlash(res, `/devis/${params.id}`, "Statut mis à jour.");
  });

  router.post("/devis/:id/convertir", async (req, res, params) => {
    const raw = Store.devis.find(params.id);
    if (!raw) return redirectWithFlash(res, "/devis", "Devis introuvable.", "error");
    if (raw.factureId) return redirectWithFlash(res, `/devis/${raw.id}`, "Ce devis a déjà été converti.", "error");

    const numero = nextNumero("FACT", Store.factures.all().map((f) => f.numero));
    const echeance = new Date();
    echeance.setDate(echeance.getDate() + 30);

    const facture = Store.factures.insert({
      numero,
      date: todayIso(),
      echeance: echeance.toISOString().slice(0, 10),
      clientId: raw.clientId,
      tauxTva: raw.tauxTva,
      datePaiement: null,
      devisId: raw.id,
      createdBy: req.user.id,
      createdAt: new Date().toISOString(),
    });

    const lignes = Store.devisLignes.where((l) => String(l.devisId) === String(raw.id));
    lignes.forEach((l) => {
      Store.factureLignes.insert({
        factureId: facture.id,
        articleId: l.articleId,
        designation: l.designation,
        quantite: l.quantite,
        prixUnitaire: l.prixUnitaire,
      });
    });

    Store.devis.update(raw.id, { factureId: facture.id });
    redirectWithFlash(res, `/factures/${facture.id}`, "Facture créée à partir du devis.");
  });
}

module.exports = { register };
