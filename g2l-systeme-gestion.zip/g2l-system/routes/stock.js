const Store = require("../lib/store");
const { renderPage, redirectWithFlash } = require("../lib/page");
const { parseBody } = require("../lib/body");
const { todayIso } = require("../lib/helpers");
const { stockOverviewBody, stockFormBody } = require("../views/stock");

function register(router) {
  router.get("/stock", async (req, res) => {
    const produits = Store.catalogue.where((a) => a.type === "Produit").sort((a, b) => a.reference.localeCompare(b.reference));
    const mouvements = Store.mouvements.all().map((m) => {
      const article = Store.catalogue.find(m.articleId);
      return { ...m, articleRef: article ? article.reference : "?" };
    });
    renderPage(res, { user: req.user, title: "Stock", active: "stock", flash: req.flash, body: stockOverviewBody({ produits, mouvements }) });
  });

  router.get("/stock/new", async (req, res) => {
    const produits = Store.catalogue.where((a) => a.type === "Produit").sort((a, b) => a.reference.localeCompare(b.reference));
    if (!produits.length) {
      return redirectWithFlash(res, "/stock", "Crée d'abord un article de type « Produit » dans le catalogue.", "error");
    }
    renderPage(res, { user: req.user, title: "Nouveau mouvement", active: "stock", flash: req.flash, body: stockFormBody({ produits, today: todayIso() }) });
  });

  router.post("/stock/new", async (req, res) => {
    const b = await parseBody(req);
    Store.mouvements.insert({
      date: b.date,
      articleId: b.articleId,
      type: b.type,
      quantite: Number(b.quantite || 0),
      refDocument: b.refDocument || "",
      commentaire: b.commentaire || "",
      createdBy: req.user.id,
    });
    redirectWithFlash(res, "/stock", "Mouvement de stock enregistré.");
  });
}

module.exports = { register };
