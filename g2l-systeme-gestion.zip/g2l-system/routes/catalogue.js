const Store = require("../lib/store");
const { renderPage } = require("../lib/page");
const { redirectWithFlash } = require("../lib/page");
const { catalogueListBody, catalogueFormBody } = require("../views/catalogue");

function register(router) {
  router.get("/catalogue", async (req, res) => {
    const items = Store.catalogue.all().sort((a, b) => a.reference.localeCompare(b.reference));
    renderPage(res, { user: req.user, title: "Catalogue", active: "catalogue", flash: req.flash, body: catalogueListBody({ items }) });
  });

  router.get("/catalogue/new", async (req, res) => {
    renderPage(res, { user: req.user, title: "Nouvel article", active: "catalogue", flash: req.flash, body: catalogueFormBody({ isEdit: false }) });
  });

  router.post("/catalogue/new", async (req, res) => {
    const { parseBody } = require("../lib/body");
    const b = await parseBody(req);
    Store.catalogue.insert({
      reference: b.reference.trim(),
      designation: b.designation.trim(),
      type: b.type,
      unite: b.unite || "",
      prixUnitaire: Number(b.prixUnitaire || 0),
      stockInitial: b.type === "Produit" ? Number(b.stockInitial || 0) : "",
      seuilAlerte: b.type === "Produit" && b.seuilAlerte !== "" ? Number(b.seuilAlerte) : "",
    });
    redirectWithFlash(res, "/catalogue", "Article ajouté au catalogue.");
  });

  router.get("/catalogue/:id/edit", async (req, res, params) => {
    const article = Store.catalogue.find(params.id);
    if (!article) return redirectWithFlash(res, "/catalogue", "Article introuvable.", "error");
    renderPage(res, { user: req.user, title: "Modifier l'article", active: "catalogue", flash: req.flash, body: catalogueFormBody({ article, isEdit: true }) });
  });

  router.post("/catalogue/:id/edit", async (req, res, params) => {
    const { parseBody } = require("../lib/body");
    const b = await parseBody(req);
    Store.catalogue.update(params.id, {
      reference: b.reference.trim(),
      designation: b.designation.trim(),
      type: b.type,
      unite: b.unite || "",
      prixUnitaire: Number(b.prixUnitaire || 0),
      stockInitial: b.type === "Produit" ? Number(b.stockInitial || 0) : "",
      seuilAlerte: b.type === "Produit" && b.seuilAlerte !== "" ? Number(b.seuilAlerte) : "",
    });
    redirectWithFlash(res, "/catalogue", "Article mis à jour.");
  });
}

module.exports = { register };
