const Store = require("../lib/store");
const { renderPage } = require("../lib/page");
const { dashboardBody } = require("../views/dashboard");
const { computeStock, statutStock, factureWithTotals } = require("../lib/business");
const { nextNumero } = require("../lib/helpers");
const { roleLabel } = require("../lib/roles");

function register(router) {
  router.get("/", async (req, res) => {
    const devisAll = Store.devis.all();
    const facturesAll = Store.factures.all().map(factureWithTotals);
    const catalogue = Store.catalogue.all();
    const demandes = Store.demandesAchat.all();

    const caFacture = facturesAll.reduce((s, f) => s + f.ttc, 0);
    const caEncaisse = facturesAll.filter((f) => f.statut === "Payée").reduce((s, f) => s + f.ttc, 0);

    const produitsAvecStock = catalogue.filter((a) => a.type === "Produit");
    const valeurStock = produitsAvecStock.reduce((s, a) => s + (computeStock(a.id) || 0) * Number(a.prixUnitaire), 0);
    const alertes = produitsAvecStock
      .filter((a) => statutStock(a) === "À réapprovisionner")
      .map((a) => ({ reference: a.reference, designation: a.designation, stock: computeStock(a.id), seuilAlerte: a.seuilAlerte }));

    const demandesEnAttenteRaw = demandes.filter((d) => d.statut === "en_attente");
    const demandesEnAttente = demandesEnAttenteRaw.map((d) => ({ ...d, directionLabel: roleLabel(d.direction) }));

    const kpis = {
      nbDevis: devisAll.length,
      nbFactures: facturesAll.length,
      caFacture,
      caEncaisse,
      valeurStock,
      articlesAlerte: alertes.length,
      demandesAttente: demandesEnAttenteRaw.length,
      prochainDevis: nextNumero("DEVIS", devisAll.map((d) => d.numero)),
      prochainFacture: nextNumero("FACT", facturesAll.map((f) => f.numero)),
    };

    renderPage(res, {
      user: req.user,
      title: "Tableau de bord",
      active: "dashboard",
      flash: req.flash,
      body: dashboardBody({ kpis, alertes, demandesEnAttente }),
    });
  });
}

module.exports = { register };
