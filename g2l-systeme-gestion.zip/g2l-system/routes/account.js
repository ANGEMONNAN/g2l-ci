const Store = require("../lib/store");
const { renderPage, redirectWithFlash } = require("../lib/page");
const { parseBody } = require("../lib/body");
const { verifyPassword, hashPassword } = require("../lib/auth");
const { escapeHtml } = require("../lib/helpers");
const { roleLabel } = require("../lib/roles");

function accountBody({ user }) {
  return `
    <div class="page-head"><div><p class="eyebrow">G2L — Mon compte</p><h1>${escapeHtml(user.nom)}</h1><p>${escapeHtml(roleLabel(user.role))} — ${escapeHtml(user.email)}</p></div></div>
    <div class="card" style="max-width:460px;">
      <h2>Changer mon mot de passe</h2>
      <form class="stack" method="POST" action="/compte/mot-de-passe">
        <div class="field"><label>Mot de passe actuel</label><input type="password" name="current" required></div>
        <div class="field"><label>Nouveau mot de passe</label><input type="password" name="next" required minlength="6"></div>
        <div class="actions"><button class="btn gold" type="submit">Mettre à jour</button></div>
      </form>
    </div>
  `;
}

function register(router) {
  router.get("/compte", async (req, res) => {
    renderPage(res, { user: req.user, title: "Mon compte", active: "", flash: req.flash, body: accountBody({ user: req.user }) });
  });

  router.post("/compte/mot-de-passe", async (req, res) => {
    const b = await parseBody(req);
    if (!verifyPassword(b.current || "", req.user.passwordHash)) {
      return redirectWithFlash(res, "/compte", "Mot de passe actuel incorrect.", "error");
    }
    Store.users.update(req.user.id, { passwordHash: hashPassword(b.next) });
    redirectWithFlash(res, "/compte", "Mot de passe mis à jour.");
  });
}

module.exports = { register };
